define(['knockout', 'jquery','appController',  'ojs/ojarraydataprovider', 'ojs/ojattributegrouphandler', 'ojs/ojconverter-number','ojs/ojknockout','ojs/ojformlayout', 'ojs/ojtoolbar', 'ojs/ojchart'],
        function (ko, $,app,ArrayDataProvider, attributeGroupHandler, NumberConverter) {
            function cpuUsageViewModel() {
                self.ProcessMetrics = ko.observableArray([]);
                self.stackValue = ko.observable('off');
                self.orientationValue = ko.observable('vertical');
                self.cpu_percent = ko.observable();
                self.cpu_count = ko.observable();
                self.cpu_speed = ko.observable();
                self.load_avg = ko.observable();

                var intId = setInterval(getCPUUsage,20000); 
                function getCPUUsage() {
                            $.ajax({
                            url: "http://192.168.0.11:8080/cpuusage",
                            type: 'GET',
                            dataType: 'json',
                            context: self,
                            error: function (e) {
                             console.log(e);
                             },
                 success: function (data) {
                    self.ProcessMetrics([]);
                    self.cpu_percent('');
                    self.cpu_count('');
                    self.cpu_speed('');
                    self.load_avg('');
                     for (var i = 0; i < data[0].length; i++) {
                         self.ProcessMetrics.push({ series : data[0][i].cpu , group :  data[0][i].quarter , thread: data[0][i].thread + ' ' + data[0][i].quarter, 'value' : data[0][i].cpu});
                     }
                     self.cpu_percent(data[1]);
                     self.cpu_count(data[2]);
                     self.cpu_speed(data[3]);
                     self.load_avg(data[4]);
                     console.log(self);
                     return self;
                 }
             })
         };




         self.colorHandler = new attributeGroupHandler.ColorAttributeGroupHandler();
         self.dataProvider = new ArrayDataProvider(self.ProcessMetrics, {keyAttributes: 'id'});
        
         self.currencyConverter = new NumberConverter.IntlNumberConverter({style: 'currency', currency: 'USD'});
         self.percentConverter = {
                    format: function(value) {
                        return value + '%';
                    }
                }


                    app.onAppSuccess();         
                    getCPUUsage();
            }
            return  cpuUsageViewModel;

        })